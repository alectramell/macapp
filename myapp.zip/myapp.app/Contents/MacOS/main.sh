#!/bin/bash

clear

echo "hello" > ~/Desktop/msg.txt

clear

open -e ~/Desktop/msg.txt

clear
